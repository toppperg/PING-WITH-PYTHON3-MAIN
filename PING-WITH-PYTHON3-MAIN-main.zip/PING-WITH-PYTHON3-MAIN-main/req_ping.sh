#!/bin/bash


#red=`tput setaf 1`
#green=`tput setaf 2`
#reset=`tput sgr0'




echo "$(tput setaf 1)HERE WE GO AGAIN!! WE KNOW YOU ARE LAZY. SIT BACK AND RELAX......WE ARE SETTING UP THINGS FOR YOU :)
DON'T FORGET TO RUN THE CODES WITH SUDO AS ICMP PACKETS NEED SUDO PRIVILEGE TO RUN $(tput sgr0)"

sudo apt update
sudo pip3 install pythonping



echo "$(tput setaf 2)YOU ARE ALL SET. GO AND CHILL..........  $(tput sgr0)"






