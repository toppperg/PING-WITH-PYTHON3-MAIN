# ping_with_python3
The most simple editable code to ping any host as you need with superfast response rate!

Don't forget to run the files with sudo as it uses ICMP packets to ping. Till now you need sudo to use ICMP packets in Linux.

!!!First install the requirments to use the ping code.!!!
Use chmod +x req_ping.sh on that directory where the file stays to make it executable.
Install the requirments by ./req_ping.sh on that same path.
